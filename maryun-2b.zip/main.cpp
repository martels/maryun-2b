//Barry Yung
//Samual Martel
//Algos Project2a
#include "Deck.h"
#include <cmath>
#include <math.h>

void playflip();

using namespace std;

int main()
{
    //play game
    playflip();
    return 0;
}

